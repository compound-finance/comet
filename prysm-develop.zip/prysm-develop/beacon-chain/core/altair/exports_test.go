package altair

var ProcessSyncAggregateEported = processSyncAggregate
