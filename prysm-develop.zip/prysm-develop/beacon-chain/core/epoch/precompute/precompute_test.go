package precompute

var ComputeCheckpoints = computeCheckpoints
