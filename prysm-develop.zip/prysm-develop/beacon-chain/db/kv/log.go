package kv

import "github.com/sirupsen/logrus"

var log = logrus.WithField("prefix", "db")
