package httprest

import "github.com/sirupsen/logrus"

var log = logrus.WithField("prefix", "httprest")
